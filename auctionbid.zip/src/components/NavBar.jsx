import useCurrentRoute from '@/hooks/useCurrentRoute'
import classNames from 'classnames'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { CaretDown, ChevronDown, Menu2, X } from 'tabler-icons-react'
import { ROUTE_INFO, ROUTES } from '@/routes'
import UserAvatar from './UserAvatar'
import { useUser } from '@/hooks/useUser'

const NavItem = ({ name, link, activeLink }) => {
	let active = link === activeLink
	return (
		<Link href={link}>
			<li
				className={classNames(
					'relative glass flex font-normal  whitespace-nowrap text-black cursor-pointer hover:underline rounded-full py-2 px-4',
					{ '!font-bold': active }
				)}>
				{name}
				<ChevronDown />
				{active && (
					<div className="absolute top-full left-1/2 -translate-x-1/2 -translate-y-2 h-1 w-1/2 rounded-md bg-gradient-to-r from-teal-800 to-green-600"></div>
				)}
			</li>
		</Link>
	)
}

const NavItemMobile = ({ name, link, activeLink, icon, closeMenu }) => {
	const user = useUser()
	let active = link === activeLink

	return (
		<Link
			href={
				name !== 'Profile' ? link : user != null ? ROUTES.PROFILE : ROUTES.LOGIN
			}
			onClick={closeMenu}
			className="block">
			<li
				className={classNames(
					'flex items-center relative uppercase whitespace-nowrap text-black hover:text-black cursor-pointer hover:bg-slate-500/30 rounded-md',
					{ 'font-bold bg-slate-400/20': active }
				)}>
				<div className="flex items-center justify-center w-12 h-12">
					{name === 'Profile' ? <UserAvatar showLink={false} /> : icon}
				</div>
				<div className="ml-4">
					{name !== 'Profile'
						? name
						: user != null
						? user?.displayName ?? user.email
						: 'Login'}
				</div>
				{active && (
					<div className="absolute top-1/2 right-3 -translate-y-1/2 h-1/2 w-1 rounded-md bg-gradient-to-r from-purple-500 to-blue-600"></div>
				)}
			</li>
		</Link>
	)
}

export const NavLinks = () => {
	const activeLink = useCurrentRoute()
	return (
		<>
			{ROUTE_INFO.filter((route) => route.id !== 'ROUTE_PROFILE').map(
				(route) => (
					<NavItem
						activeLink={activeLink}
						key={route.id}
						link={route.path}
						name={route.name}
					/>
				)
			)}
		</>
	)
}

export const NavLinksMobile = ({ closeMenu }) => {
	const activeLink = useCurrentRoute()
	return (
		<>
			{ROUTE_INFO.map((route) => (
				<NavItemMobile
					activeLink={activeLink}
					icon={route.icon}
					key={route.id}
					link={route.path}
					name={route.name}
					closeMenu={closeMenu}
				/>
			))}
		</>
	)
}

const Navbar = () => {
	const [menuOpen, setMenuOpen] = useState(false)

	useEffect(() => {
		document.querySelector('body').style.overflow = menuOpen ? 'hidden' : 'auto'
	}, [menuOpen])

	return (
		<>
			<nav className="hidden  md:block">
				<ul className="rounded-full font-semibold text-black p-2 flex items-center space-x-2">
					<NavLinks />
					<UserAvatar />
				</ul>
			</nav>
			<nav className=" relative md:hidden">
				<div
					className={
						'glass uppercase whitespace-nowrap text-black hover:text-black cursor-pointer hover:bg-teal-400/20 rounded-full p-4'
					}
					onClick={() => {
						setMenuOpen((s) => !s)
					}}>
					{menuOpen ? <X /> : <Menu2 />}
				</div>
				<div
					className={classNames(
						'translate-x-[110vw] glass p-0 transition-all fixed w-full h-full sm:max-w-[24rem] top-0 right-0 rounded-none border-0 md:border-l',
						{ '!translate-x-0': menuOpen }
					)}>
					<div className="h-20 flex items-center p-4">
						<div className="flex-1 text-black text-xl">MENU</div>
						<div>
							<button
								onClick={() => setMenuOpen((_) => false)}
								className="glass uppercase whitespace-nowrap text-black hover:text-black cursor-pointer hover:bg-slate-400/20 rounded-full p-4">
								<X />
							</button>
						</div>
					</div>
					<ul className="p-4 pt-0 space-y-2">
						<NavLinksMobile closeMenu={() => setMenuOpen(false)} />
					</ul>
				</div>
			</nav>
		</>
	)
}

export default Navbar
