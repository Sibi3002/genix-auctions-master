import React from 'react'

const ItemTile = () => {
	return <div>ItemTile</div>
}

export default ItemTile
