import { ROUTES } from '@/routes'
import Image from 'next/image'
import Link from 'next/link'
import { useUser } from '@/hooks/useUser'
import { User } from 'tabler-icons-react'

const UserAvatar = ({ showLink = true }) => {
	const currentUser = useUser()
	let photoURL = `https://api.dicebear.com/5.x/bottts-neutral/svg?seed=${currentUser?.uid}`

	return currentUser ? (
		showLink ? (
			<Link href={ROUTES.PROFILE}>
				<div className="flex rounded-full overflow-hidden items-center justify-center w-10 h-10 text-black hover:text-white hover:bg-slate-400/20 cursor-pointer">
					<Image
						alt={currentUser?.displayName}
						width={40}
						height={40}
						src={photoURL}
						dangerouslyallowsvg="true"
					/>
				</div>
			</Link>
		) : (
			<div className="flex rounded-full overflow-hidden items-center justify-center w-10 h-10 text-black hover:text-white hover:bg-slate-400/20 cursor-pointer">
				<Image
					alt={currentUser?.displayName}
					width={40}
					height={40}
					src={photoURL}
				/>
			</div>
		)
	) : showLink ? (
		<div className="flex gap-x-5">
			<Link href={ROUTES.LOGIN}>
				<div className="flex  overflow-hidden items-center justify-center  h-10 text-blue-500 hover:text-white hover:bg-slate-400/20 cursor-pointer">
					Login
				</div>
			</Link>
			<Link href={ROUTES.SIGNGIN}>
				<div className="flex  overflow-hidden items-center justify-center  h-10 bg-blue-500 rounded-sm px-2 text-white hover:text-white hover:bg-slate-400/20 cursor-pointer">
					Get Started
				</div>
			</Link>
		</div>
	) : (
		<div className="flex rounded-full overflow-hidden items-center justify-center w-10 h-10 text-black hover:text-white hover:bg-slate-400/20 cursor-pointer">
			<User strokeWidth={3} stroke="currentColor" />
		</div>
	)
}

export default UserAvatar
