import React, { useState } from 'react'
import { ChevronRight, Heart } from 'tabler-icons-react'

const AuctionCard = ({ props }) => {
	const { imageUrl, title, minimumBid, currentBid, timeRemaining } = props
	const [liked, setLiked] = useState(false)
	return (
		<div className="bg-white rounded-lg shadow-gray-500 hover:border-2 border-blue-600 shadow-md p-4">
			<div className="relative">
				<img
					src={imageUrl}
					alt={title}
					className="w-[16em] shadow-md  h-[14em] rounded-t-lg"
				/>
				{liked ? (
					<button
						onClick={() => setLiked(false)}
						className="absolute top-2 right-2 border-2 rounded-full  text-red-500 hover:text-red-700">
						<Heart fill="#ff0000" />
					</button>
				) : (
					<button
						onClick={() => setLiked(true)}
						className="absolute border-2  rounded-full  text-black top-2 right-2 ">
						<Heart />
					</button>
				)}
			</div>
			<div className="text-green-500 font-semibold mt-2">Live Auction</div>
			<h3 className="text-xl font-bold">{title}</h3>
			<p className="text-gray-600">Minimum Bid: ${minimumBid}</p>
			<p className="text-gray-600">Current Bid: ${currentBid}</p>
			<p className="text-gray-600">Ends in: {timeRemaining}</p>
			<button className="mt-4 w-full flex align-middle items-center justify-center bg-gradient-to-r from-red-500 to-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded-lg">
				Bid now <ChevronRight />
			</button>
		</div>
	)
}

export default AuctionCard
