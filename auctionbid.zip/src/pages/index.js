import Image from 'next/image'
import { Inter } from 'next/font/google'
import AuctionCard from '@/components/AuctionCard'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {
	const auction = {
		imageUrl:
			'https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1715261605/Croma%20Assets/Entertainment/Wireless%20Earbuds/Images/270439_nltbfg.png?tr=w-640',
		title: 'boat',
		minimumBid: '167',
		currentBid: '180',
		timeRemaining: '2 days',
	}
	return (
		<main
			className={`flex min-h-screen flex-col items-center justify-between p-24 ${inter.className}`}>
			<div className="z-10 max-w-5xl w-full items-center justify-between font-mono text-sm lg:flex">
				<AuctionCard props={auction} />
			</div>
		</main>
	)
}
