import Footer from '@/components/Footer'
import Header from '@/components/Header'
import '@/styles/globals.css'

export default function App({ Component, pageProps }) {
	return (
		<div>
			<div className="fixed  bg-pink-100  w-full m-0 top-0 left-0 z-50">
				<Header />
			</div>
			<div className="relative top-[5rem] min-h-screen">
				<Component {...pageProps} />
			</div>

			<div className="mt-24">
				<Footer />
			</div>
		</div>
	)
}
